// src/pages/FormIsian.jsx
import React from "react";
import { useFormContext } from "../context/FormContext";
import { useNavigate } from "react-router-dom";
import InputField from "../components/InputField";

export default function FormIsian() {
  const navigate = useNavigate();
  const { formData, setFormData } = useFormContext();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleDropdownChange = (group, selected) => {
    setFormData((prev) => {
      const updatedGroup = Object.keys(prev)
        .filter((key) => key.startsWith(group))
        .reduce((acc, key) => {
          acc[key] = key === selected ? "√" : ""; // Berikan "√" untuk yang dipilih, kosongkan yang lain
          return acc;
        }, {});
      return { ...prev, ...updatedGroup };
    });
  };

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold mb-4">Form Isian</h1>

      {/* Data Utama FPP */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Data Utama FPP</h2>
        <InputField label="Nomor FPP" name="nomor_fpp" value={formData.nomor_fpp} onChange={handleChange} />
        <InputField label="Tahun FPP" name="tahun_fpp" value={formData.tahun_fpp} onChange={handleChange} />
        <InputField label="Tanggal FPP" name="tanggal_fpp" value={formData.tanggal_fpp} onChange={handleChange} />
        <InputField label="Pasal Pelanggaran" name="pasal_pelanggaran" value={formData.pasal_pelanggaran} onChange={handleChange} />
        <InputField label="Isi Pasal Pelanggaran" name="isi_pasal_pelanggaran" value={formData.isi_pasal_pelanggaran} onChange={handleChange} />
      </section>

      {/* Resume Pengaduan */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Resume Pengaduan</h2>
        <InputField label="Sumber Pengaduan" name="sumber_pengaduan" value={formData.sumber_pengaduan} onChange={handleChange} />
        <InputField label="Info Tambahan Sumber Pengaduan" name="info_tambahan_sumber_pengaduan" value={formData.info_tambahan_sumber_pengaduan} onChange={handleChange} />
        <InputField label="Resume Pengaduan" name="resume_pengaduan" value={formData.resume_pengaduan} onChange={handleChange} />
      </section>

      {/* Data Terlapor */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Data Terlapor</h2>
        <InputField label="Nama Terlapor" name="nama_terlapor_1" value={formData.nama_terlapor_1} onChange={handleChange} />
        <InputField label="NIP Terlapor" name="nip_terlapor_1" value={formData.nip_terlapor_1} onChange={handleChange} />
        <InputField label="Jabatan Terlapor" name="jabatan_terlapor_1" value={formData.jabatan_terlapor_1} onChange={handleChange} />
        <InputField label="Unit Kerja Terlapor" name="unit_kerja_terlapor" value={formData.unit_kerja_terlapor} onChange={handleChange} />
      </section>

      {/* Data Pelapor */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Data Pelapor</h2>
        <InputField label="Nama Pelapor" name="nama_pelapor" value={formData.nama_pelapor} onChange={handleChange} />
        <InputField label="Alamat Pelapor" name="alamat_pelapor" value={formData.alamat_pelapor} onChange={handleChange} />
        <InputField label="Telepon Pelapor" name="telepon_pelapor" value={formData.telepon_pelapor} onChange={handleChange} />
      </section>

      {/* Analisis Pengaduan */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Analisis Pengaduan</h2>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Isi Pengaduan
          </label>
          <select
            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            onChange={(e) =>
              handleDropdownChange("centang_analisis", e.target.value)
            }
          >
            <option value="">Pilih</option>
            <option value="centang_analisis_1">
              Pelanggaran Kode Etik dan/atau Disiplin
            </option>
            <option value="centang_analisis_2">
              Bukan Pelanggaran Kode Etik dan/atau Disiplin
            </option>
          </select>
        </div>
      </section>

      {/* Kriteria Pelanggaran */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Kriteria Pelanggaran</h2>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Pilih Kriteria
          </label>
          <select
            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            onChange={(e) => handleDropdownChange("cka", e.target.value)}
          >
            <option value="">Pilih</option>
            <option value="cka_1">Berdampak pada Citra DJP</option>
            <option value="cka_2">Bernilai Strategis</option>
            <option value="cka_3">Berskala Nasional</option>
          </select>
        </div>
      </section>

      {/* Pembentukan Tim Pulbaket */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Pembentukan Tim Pulbaket</h2>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Pilih Opsi
          </label>
          <select
            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            onChange={(e) =>
              handleDropdownChange("centang_pulbaket", e.target.value)
            }
          >
            <option value="">Pilih</option>
            <option value="centang_pulbaket_1">Ya, Bentuk Tim Pulbaket</option>
            <option value="centang_pulbaket_2">Tidak, Bentuk Tim Pulbaket</option>
          </select>
        </div>
      </section>

      {/* Kriteria Layak Investigasi */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Kriteria Layak Investigasi</h2>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Pilih Kriteria
          </label>
          <select
            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            onChange={(e) => handleDropdownChange("cdi", e.target.value)}
          >
            <option value="">Pilih</option>
            <option value="cdi_1">Berdampak terhadap Citra DJP</option>
            <option value="cdi_2">Bernilai Strategis</option>
            <option value="cdi_3">Berskala Nasional</option>
          </select>
        </div>
      </section>

      {/* Usul Tindak Lanjut */}
      <section>
        <h2 className="text-lg font-semibold mb-2">Usul Tindak Lanjut</h2>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Pilih Usul
          </label>
          <select
            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            onChange={(e) => handleDropdownChange("utl", e.target.value)}
          >
            <option value="">Pilih</option>
            <option value="utl_1">Investigasi</option>
            <option value="utl_2">Penerusan Tim Litdal</option>
            <option value="utl_3">Penerusan ke Atsung</option>
            <option value="utl_4">Penerusan ke Unit Terkait</option>
            <option value="utl_5">Arsip</option>
          </select>
        </div>
      </section>

      {/* Tombol Navigasi */}
      <div className="mt-8">
        <button
          onClick={() => navigate("/preview")}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Lihat Preview
        </button>
      </div>
    </div>
  );
}
